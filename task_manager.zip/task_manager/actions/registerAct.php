<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($user) || empty($email) || empty($password)) {
        echo "All fields are required.";
        exit;
    }

    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
    $stmt->execute(['username' => $user, 'email' => $email]);
    if ($stmt->rowCount() > 0) {
        echo "Username or email already exists.";
        header('Location: ../register.php');
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, created_at) VALUES (:username, :email, :password, CURRENT_TIMESTAMP)");
    $stmt->execute([
        'username' => $user,
        'email' => $email,
        'password' => $password
    ]);

    header('Location: ../login.php');
}
?>
