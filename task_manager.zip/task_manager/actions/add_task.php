<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.html');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userId = $_SESSION['user_id'];
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $dueDate = $_POST['due_date'];
    $categoryId = $_POST['category_id'] ?? null;

    if (empty($title)) {
        $_SESSION['error'] = 'Task title is required';
        header('Location: ../index.php');
        exit();
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO tasks (user_id, title, description, due_date, category_id, created_at, updated_at) 
                               VALUES (:user_id, :title, :description, :due_date, :category_id, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)");
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':title', $title, PDO::PARAM_STR);
        $stmt->bindParam(':description', $description, PDO::PARAM_STR);
        $stmt->bindParam(':due_date', $dueDate, PDO::PARAM_STR);
        $stmt->bindParam(':category_id', $categoryId, PDO::PARAM_INT);
        $stmt->execute();

        $_SESSION['success'] = 'Task added successfully';
        header('Location: ../index.php');
        exit();
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Error adding task: ' . $e->getMessage();
        header('Location: ../index.php');
        exit();
    }
} else {
    header('Location: ../index.php');
    exit();
}
