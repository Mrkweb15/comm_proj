<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $categoryName = $_POST['name'];

    $sql = "INSERT INTO categories (name) VALUES (:name)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':name', $categoryName, PDO::PARAM_STR);

    try {
        $stmt->execute();
        header("Location: ../index.php");
        exit();
    } catch (PDOException $e) {
        die("Error adding category: " . $e->getMessage());
    }
}
?>
