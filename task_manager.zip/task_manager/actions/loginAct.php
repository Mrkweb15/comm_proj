<?php
session_start();
require_once 'db.php';

$response = ['success' => false, 'message' => 'Invalid request'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    if (empty($user) || empty($pass)) {
        $response['message'] = 'Please fill in all fields.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id, password FROM users WHERE username = :username");
            $stmt->bindParam(':username', $user);
            $stmt->execute();
            $userData = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($userData) {
                if ($pass === $userData['password']) {
                    $_SESSION['user_id'] = $userData['id'];
                    $response['success'] = true;
                    $response['message'] = 'Login successful.';
                } else {
                    $response['message'] = 'Password does not match.';
                }
            } else {
                $response['message'] = 'Username not found.';
            }
        } catch (PDOException $e) {
            $response['message'] = 'Database error: ' . $e->getMessage();
        }
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>
