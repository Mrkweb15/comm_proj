<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Not logged in']);
    exit();
}

if (isset($_POST['id']) && isset($_POST['status'])) {
    $taskId = $_POST['id'];
    $status = $_POST['status'];

    $validStatuses = ['Task', 'Done', 'Canceled', 'Ignored'];
    if (!in_array($status, $validStatuses)) {
        echo json_encode(['error' => 'Invalid status']);
        exit();
    }

    try {
        $stmt = $pdo->prepare("UPDATE tasks SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE id = :id AND user_id = :user_id");
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
        $stmt->bindParam(':id', $taskId, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->execute();

        echo json_encode(['success' => 'Status updated']);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Error updating status: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Missing task ID or status']);
}
