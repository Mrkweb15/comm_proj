<?php
session_start();
require_once 'actions/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

//sorting by due date or category
$sortBy = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'due_date';
$order = isset($_GET['order']) ? $_GET['order'] : 'ASC';

$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'Pending';

// get tasks for the user
$userId = $_SESSION['user_id'];
try {
    $sql = "SELECT id, title, description, due_date, status, category_id FROM tasks WHERE user_id = :user_id AND status = :status";
    
    $sql .= " ORDER BY $sortBy $order";
    
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->bindParam(':status', $statusFilter, PDO::PARAM_STR);
    
    $stmt->execute();
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching tasks: " . $e->getMessage());
}

//categories for the dropdown
try {
    $categoryStmt = $pdo->query("SELECT id, name FROM categories");
    $categories = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching categories: " . $e->getMessage());
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Tasks</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">My Tasks</h2>

        <!-- Navbar for Sorting and Status Filters -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between">
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="sortDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            Sort By
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="sortDropdown">
                            <li><a class="dropdown-item" href="?sort_by=due_date&order=ASC">Due Date (Ascending)</a></li>
                            <li><a class="dropdown-item" href="?sort_by=due_date&order=DESC">Due Date (Descending)</a></li>
                            <li><a class="dropdown-item" href="?sort_by=category_id&order=ASC">Category (Ascending)</a></li>
                            <li><a class="dropdown-item" href="?sort_by=category_id&order=DESC">Category (Descending)</a></li>
                        </ul>
                    </div>

                    <!-- Status Filters -->
                    <div class="btn-group" role="group">
                        <a href="?status=Pending&sort_by=<?php echo $sortBy; ?>&order=<?php echo $order; ?>" class="btn btn-outline-primary">Pending</a>
                        <a href="?status=Done&sort_by=<?php echo $sortBy; ?>&order=<?php echo $order; ?>" class="btn btn-outline-success">Done</a>
                        <a href="?status=Canceled&sort_by=<?php echo $sortBy; ?>&order=<?php echo $order; ?>" class="btn btn-outline-danger">Canceled</a>
                        <a href="?status=Ignored&sort_by=<?php echo $sortBy; ?>&order=<?php echo $order; ?>" class="btn btn-outline-secondary">Ignored</a>
                    </div>
                        
                    <!-- Add Category Button -->
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">Add Category</button>
                    
                    <!-- Logout Button -->
                    <a href="actions/logout.php" class="btn btn-danger">Logout</a>
                </div>

            </div>
        </div>

        <!-- Task List -->
        <div class="row">
            <?php if (empty($tasks)): ?>
                <div class="col-12">
                    <p class="text-center">No tasks found.</p>
                </div>
            <?php else: ?>
                <?php foreach ($tasks as $task): ?>
                    <div class="col-md-4 col-sm-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-warning text-center">
                                <strong><?php echo htmlspecialchars($task['title']); ?></strong>
                            </div>
                            <div class="card-body">
                                <p class="card-text"><?php echo htmlspecialchars($task['description'] ?: 'No description provided.'); ?></p>
                                <p class="text-muted">Due: <?php echo htmlspecialchars($task['due_date'] ?: 'No due date'); ?></p>
                                <p class="text-<?php echo strtolower($task['status']); ?>" id="status-<?php echo $task['id']; ?>">
                                    Status: <?php echo htmlspecialchars($task['status']); ?>
                                </p>
                            </div>
                            <div class="buttons">
                                <button class="btn btn-success btn-sm update-status" data-id="<?php echo $task['id']; ?>" data-status="Done">Done</button>
                                <button class="btn btn-danger btn-sm update-status" data-id="<?php echo $task['id']; ?>" data-status="Canceled">Cancel</button>
                                <button class="btn btn-secondary btn-sm update-status" data-id="<?php echo $task['id']; ?>" data-status="Ignored">Ignore</button>
                                <button class="btn btn-secondary btn-sm delete-task" data-id="<?php echo $task['id']; ?>" data-status="Ignored">Delete</button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
    </div>

    <button type="button" class="btn btn-primary position-fixed bottom-0 end-0 m-3" data-bs-toggle="modal" data-bs-target="#addTaskModal" style="font-size: 24px; border-radius: 50%; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
        +
    </button>


    <!-- Modal for Adding Task -->
    <div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="addTaskModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addTaskModalLabel">Add New Task</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="actions/add_task.php" method="POST">
                        <div class="mb-3">
                            <label for="taskTitle" class="form-label">Task Title</label>
                            <input type="text" class="form-control" id="taskTitle" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="taskDescription" class="form-label">Task Description</label>
                            <textarea class="form-control" id="taskDescription" name="description"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="taskDueDate" class="form-label">Due Date</label>
                            <input type="date" class="form-control" id="taskDueDate" name="due_date">
                        </div>
                        <div class="mb-3">
                            <label for="taskCategory" class="form-label">Category</label>
                            <select class="form-control" id="taskCategory" name="category_id">
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Add Task</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Adding Category -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCategoryModalLabel">Add New Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="actions/add_category.php" method="POST">
                <div class="mb-3">
                    <label for="categoryName" class="form-label">Category Name</label>
                    <input type="text" class="form-control" id="categoryName" name="name" required>
                </div>
                <button type="submit" class="btn btn-primary">Add Category</button>
                </form>
            </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            //update status
            $('.update-status').click(function() {
                var taskId = $(this).data('id');
                var status = $(this).data('status');

                $.ajax({
                    url: 'actions/update_task_status.php',
                    type: 'POST',
                    data: { id: taskId, status: status },
                    success: function(response) {
                        $('#status-' + taskId).text('Status: ' + status).removeClass().addClass('text-' + status.toLowerCase());
                    },
                    error: function() {
                        alert('An error occurred while updating the status.');
                    }
                });
            });

            //delete task
            $('.delete-task').click(function() {
                var taskId = $(this).data('id');

                if (confirm('Are you sure you want to delete this task?')) {
                    $.ajax({
                        url: 'actions/delete_task.php',
                        type: 'POST',
                        data: { id: taskId },
                        success: function(response) {
                            var result = JSON.parse(response);
                            if (result.status == 'success') {
                                alert(result.message);
                                location.reload();

                            } else {
                                alert('Error: ' + result.message);
                            }
                        },
                        error: function() {
                            alert('An error occurred while deleting the task.');
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
